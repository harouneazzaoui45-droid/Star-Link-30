import 'package:flutter/material.dart';

void main() => runApp(const StartLinkApp());

class StartLinkApp extends StatelessWidget {
  const StartLinkApp({super.key});

  @override
  Widget build(BuildContext context) {
    const mainColor = Color(0xFF6A3DB8);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'تطبيق المدير',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: mainColor),
        fontFamily: 'Roboto',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('StartLink'),
          centerTitle: true,
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: const Color(0xFF6A3DB8).withOpacity(.10),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.hub_rounded, size: 42),
                  const SizedBox(height: 14),
                  Text('تطبيق المدير', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('إدارة منصة StartLink ومراقبة النشاط.'),
                ],
              ),
            ),
            const SizedBox(height: 22),
            Text('الخدمات الرئيسية', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _FeatureCard(icon: Icons.people, title: 'إدارة المستخدمين', description: 'متابعة حسابات الزبائن والمؤسسات.'),,
            _FeatureCard(icon: Icons.verified, title: 'مراجعة المؤسسات', description: 'مراجعة طلبات انضمام المؤسسات.'),,
            _FeatureCard(icon: Icons.analytics, title: 'إحصائيات المنصة', description: 'نظرة عامة على نشاط المنصة.'),
            const SizedBox(height: 18),
            const Text('نسخة تجريبية أولية — سيتم إضافة الحسابات وقاعدة البيانات في المرحلة التالية.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54, height: 1.5)),
          ],
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  const _FeatureCard({required this.icon, required this.title, required this.description});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(description),
        trailing: const Icon(Icons.chevron_left),
      ),
    );
  }
}
